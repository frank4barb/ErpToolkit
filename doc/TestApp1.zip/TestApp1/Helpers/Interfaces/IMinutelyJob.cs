﻿using Quartz;

namespace Backup.Service.Helpers.Interfaces
{
    public interface IMinutelyJob : IJob { }
}
