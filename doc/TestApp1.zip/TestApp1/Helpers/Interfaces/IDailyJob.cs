﻿using Quartz;

namespace Backup.Service.Helpers.Interfaces
{
    public interface IDailyJob: IJob { }
}
