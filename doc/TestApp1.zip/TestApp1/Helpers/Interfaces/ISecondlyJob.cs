﻿using Quartz;

namespace Backup.Service.Helpers.Interfaces
{
    public interface ISecondlyJob : IJob { }
}
