﻿using Microsoft.VisualBasic;
using System.Collections;
using System.Collections.Generic;
using static System.Net.Mime.MediaTypeNames;
using System.Net.Http;
using System.Text;

namespace Backup.Service
{
    //classe SINGLETON con il contesto dello scheduler 
    public class Context
    {
        private static Context? _instance;
        private IDictionary _items;

        private Context()
        {
            //load DHEdesktop.ini
            string ServicePath = Environment.CurrentDirectory;
            string FileName = ServicePath + "\\" + "DHEdesktop.ini";
            _items = readIniFile(FileName);


        }
        public static Context Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new Context();
                return _instance;
            }
        }

        //public IDictionary Items
        //{
        //    get
        //    {
        //        return _items;
        //    }
        //}

        public object? GetObjectParam(string name)
        {
            if (_items.Contains(name)) return _items[name];
            return null;
        }
 
        public void SetObjectParam(string name, object? value)
        {
           _items[name] = value;
        }
        public string GetParam(string name)
        {
            object? value = GetObjectParam(name);
            if (value == null) return "";
            return (string)value;
        }

        //private
        private static IDictionary readIniFile(string FileName)
        {
            IDictionary items = new Dictionary<string, object>();
            FileStream? fs; StreamReader? sr;
            if (System.IO.File.Exists(FileName))
            {
                try
                {
                    fs = new FileStream(FileName, FileMode.OpenOrCreate, FileAccess.Read, FileShare.Read);
                    sr = new StreamReader(fs, Encoding.UTF8);
                    while (true)
                    {
                        string line = Strings.Trim(sr.ReadLine()); line = Strings.Replace(line, Constants.vbTab, " "); line = Strings.Trim(line);
                        if (line != "" && line.StartsWith(";") == false)
                        {
                            string name = ""; string value = ""; int idx = line.IndexOf(' ');
                            if (idx > 0)
                            {
                                name = Strings.Trim(Strings.Mid(line, 1, idx + 1));
                                value = Strings.Trim(Strings.Mid(line, idx + 1));
                                items.Add(name, value);
                            }
                        }
                        if (sr.EndOfStream) break;
                    }
                    sr.Close(); fs.Close(); sr = null; fs = null;
                }
                catch (Exception ex) { sr = null; fs = null; }
            }
            return items;
        }


    }
}
