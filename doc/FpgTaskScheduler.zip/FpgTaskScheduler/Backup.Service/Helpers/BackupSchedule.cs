﻿namespace Backup.Service.Helpers
{
    public static class BackupSchedule
    {
        public static readonly string Daily = "daily";
        public static readonly string Weekly = "weekly";
        public static readonly string Monthly = "monthly";
    }
}
